import React from 'react';
import html2pdf from 'html2pdf.js';
import './resume.css';
import styled from 'styled-components';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faDownload, faArrowLeft } from '@fortawesome/free-solid-svg-icons';

const StyledButton = styled.button`
  position: fixed;
  bottom: 20px; 
  right: 20px;
  background-color: #007bff;
  color: #ffffff;
  border: none;
  width: 150px; 
  height: 50px;
  border-radius: 5px;
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #0056b3;
  }
`;

const StyledButtonNext = styled.button`
  position: fixed;
  bottom: 20px; 
 margin-left: 20px;
  background-color: #007bff;
  color: #ffffff;
  border: none;
  width: 150px; 
  height: 50px;
  border-radius: 5px;
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #0056b3;
  }
 `;


class Resume extends React.Component {
    downloadPDF = () => {
        const element = document.querySelector('.containertwo');
        const opt = {
            filename:     'non-technical-resume.pdf',
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2 },
            jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
        };

        html2pdf().from(element).set(opt).save();
    };

    render() {
        return (
     <>
     <StyledButton onClick={this.downloadPDF}>
        <FontAwesomeIcon icon={faDownload} style={{ marginRight: '5px', fontSize: '24px', color: 'white' }} />
        Download
      </StyledButton>
      <StyledButtonNext>
        <FontAwesomeIcon icon={faArrowLeft} style={{ marginRight: '5px', fontSize: '24px', color: 'white' }} />
        Back
      </StyledButtonNext>
                
      <div className="containertwo">
        <div className="headertwo">
          <div className="full-name" contentEditable="true">
            <span className="first-name">John</span> 
            <span className="last-name">Doe</span>
          </div>
          <div className="contact-infotwo" contentEditable="true">
            <span className="email">Email: </span>
            <span className="email-val">john.doe@gmail.com</span>
            <span className="separators" />
            <span className="phone">Phone: </span>
            <span className="phone-val">111-222-3333</span>
          </div>
          <div style={{ width: '100%', borderBottom: '1px solid black' }}></div>
          <div className="about" contentEditable="true">
            <span className="position">Front-End Developer </span>
            <span className="desc">
              I am a front-end developer with more than 3 years of experience writing html, css, and js. I'm motivated, result-focused and seeking a successful team-oriented company with opportunity to grow. 
            </span>
          </div>
        </div><div style={{ width: '100%', borderBottom: '1px solid black' }}></div>
        
        <div className="detailstwo">
          <div className="sectiontwo">
          <div style={{ width: '100%', borderTop: '1px solid black',marginBottom:"5px"}}></div>
            <div className="section__title">Experience</div>
            <div style={{ width: '100%', borderTop: '1px solid black' }}></div>
            <div className="section__list">
              <div className="section__list-item">
                <div className="left" contentEditable="true">
                  <div className="name">KlowdBox</div>
                  <div className="addr">San Fr, CA</div>
                  <div className="duration">Jan 2011 - Feb 2015</div>
                </div>
                <div className="right" contentEditable="true">
                  <div className="name">Fr developer</div>
                  <div className="desc">did This and that</div>
                </div>
              </div>
              <div className="section__list-item">
                <div className="left" contentEditable="true">
                  <div className="name">Akount</div>
                  <div className="addr">San Monica, CA</div>
                  <div className="duration">Jan 2011 - Feb 2015</div>
                </div>
                <div className="right" contentEditable="true">
                  <div className="name">Fr developer</div>
                  <div className="desc">did This and that</div>
                </div>
              </div>
            </div>
          </div>
          <div className="sectiontwo">
          <div style={{ width: '100%', borderTop: '1px solid black',marginBottom:"5px"}}></div>
            <div className="section__title">Education</div>
            <div style={{ width: '100%', borderTop: '1px solid black',marginBottom:"5px"}}></div>
            <div className="section__list">
              <div className="section__list-item">
                <div className="left" contentEditable="true">
                  <div className="name">Sample Institute of technology</div>
                  <div className="addr">San Fr, CA</div>
                  <div className="duration">Jan 2011 - Feb 2015</div>
                </div>
                <div className="right" contentEditable="true">
                  <div className="name">Fr developer</div>
                  <div className="desc">did This and that</div>
                </div>
              </div>
              <div className="section__list-item">
                <div className="left" contentEditable="true">
                  <div className="name">Akount</div>
                  <div className="addr">San Monica, CA</div>
                  <div className="duration">Jan 2011 - Feb 2015</div>
                </div>
                <div className="right" contentEditable="true">
                  <div className="name">Fr developer</div>
                  <div className="desc">did This and that</div>
                </div>
              </div>
            </div>
          </div><div style={{ width: '100%', borderBottom: '1px solid black' }}></div>
          <div className="sectiontwo">
          <div style={{ width: '100%', borderTop: '1px solid black',marginBottom:"5px"}}></div>
            <div className="section__title">Projects</div> 
            <div style={{ width: '100%', borderTop: '1px solid black' }}></div>
            <div className="section__list">
              <div className="section__list-item" contentEditable="true">
                <div className="name">DSP</div>
                <div className="text">I am a front-end developer with more than 3 years of experience writing html, css, and js. I'm motivated, result-focused and seeking a successful team-oriented company with opportunity to grow.</div>
              </div>
              <div className="section__list-item" contentEditable="true">
                <div className="name">DSP</div>
                <div className="text">I am a front-end developer with more than 3 years of experience writing html, css, and js. I'm motivated, result-focused and seeking a successful team-oriented company with opportunity to grow. <a href="/login">link</a>
                </div>
              </div>
            </div>
          </div><div style={{ width: '100%', borderBottom: '1px solid black' }}></div>
          <div className="sectiontwo">
            <div className="section__title">Skills</div>
            <div style={{ width: '100%', borderTop: '1px solid black',marginBottom:"5px"}}></div>
            <div className="skills" contentEditable="true">
              <div className="skills__item">
                <div className="left"><div className="name">
                    Javascript
                  </div></div>
                <div className="right" contentEditable="true">
                  <input id="ck1" type="checkbox" defaultChecked />
                  <label htmlFor="ck1" />
                  <input id="ck2" type="checkbox" defaultChecked />
                  <label htmlFor="ck2" />
                  <input id="ck3" type="checkbox" defaultChecked />
                  <label htmlFor="ck3" />
                  <input id="ck4" type="checkbox" />
                  <label htmlFor="ck4" />
                  <input id="ck5" type="checkbox" />
                  <label htmlFor="ck5" />
                </div>
              </div>
            </div>
            <div className="skills__item" contentEditable="true">
              <div className="left"><div className="name">
                  CSS</div></div>
              <div className="right" contentEditable="true">
                <input id="ck1" type="checkbox" defaultChecked />
                <label htmlFor="ck1" />
                <input id="ck2" type="checkbox" defaultChecked />
                <label htmlFor="ck2" />
                <input id="ck3" type="checkbox" />
                <label htmlFor="ck3" />
                <input id="ck4" type="checkbox" />
                <label htmlFor="ck4" />
                <input id="ck5" type="checkbox" />
                <label htmlFor="ck5" />
              </div>
            </div>
          </div>
          <div className="sectiontwo">
         <div style={{ width: '100%', borderTop: '1px solid black',marginBottom:"5px"}}></div>
            <div className="section__title" contentEditable="true">
              Interests
            </div><div style={{ width: '100%', borderTop: '1px solid black',marginBottom:"5px"}}></div>
            <div className="section__list" contentEditable="true">
              <div className="section__list-item">
                Football, programming.
              </div>
            </div>
          </div>
        </div>
        <div/>
        <div>
          </div>
        </div>
        </>             
      );
  }
};

export default Resume;
