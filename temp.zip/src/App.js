import React from 'react';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Tempone from "./Template/Tempone";
import Temptwo from "./Temptwo/Resume";
import Temthree from "./Tempthree/ResumeWrapper";
import Tempfour from "./TemoFour/Tempfour";
import Tempfive from "./Tempfive/tempfive";



const App = () => {
    return (
        <BrowserRouter>
      <Routes>
      <Route path="/" element={<Temthree />} />
        <Route path="/Tempone"  element={<Tempone/>} />
        <Route path="/Resume"  element={<Temptwo/>} />
        <Route path="/ResumeWrapper " element={<Temthree />} />
        <Route path="/Tempfour" element={<Tempfour />} />
        <Route path="/Tempfive" element={<Tempfive />} />
      </Routes>
    </BrowserRouter>
    );
};

export default App;
