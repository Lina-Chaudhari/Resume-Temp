import React from 'react';
import './tempfive.css';
import html2pdf from 'html2pdf.js';

const Tempfive = () => {
    const downloadPDF = () => { 
        const element = document.querySelector('.resume-wrapper');
        const opt = {
          margin: 0.5,
          filename: 'resume.pdf',
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2 },
          jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
        };
    
        html2pdf().from(element).set(opt).save();
      };

    return (
        <>
            <button onClick={downloadPDF} 
                style={{
                    width: '200px',
                    height: '25px',
                    borderRadius: '10px',
                    marginLeft: '40%',
                    backgroundColor: 'red',
                    color: 'white',
                    marginTop: '5px'
                }}>
                Download as PDF
            </button>
        <div className="resume-wrapper">
          <section className="profile section-padding">
            <div className="container">
              <div className="picture-resume-wrapper">
                <div className="clearfix" />
              </div>
              <div className="name-wrapper">
                <h1 contentEditable="true" >John <br />Anderson</h1>
              </div>
              <div className="clearfix" />
              <div className="contact-info clearfix" contentEditable="true">
                <ul className="list-titles">
                  <li>Call</li>
                  <li>Mail</li>
                  <li>Web</li>
                  <li>Home</li>
                </ul>
                <ul className="list-content" contentEditable="true">
                  <li>+34 123 456 789</li>
                  <li>j.anderson@gmail.com</li> 
                  <li><a href="#">janderson.com</a></li> 
                  <li>Los Angeles, CA</li> 
                </ul>
              </div>
              <div className="contact-presentation" contentEditable="true"> 
                <p><span className="bold">Lorem</span> ipsum dolor sit amet, consectetur adipiscing elit. Vivamus euismod congue nisi, nec consequat quam. In consectetur faucibus turpis eget laoreet. Sed nec imperdiet purus. </p>
              </div>
              <div className="contact-social clearfix" contentEditable="true">
                <ul className="list-titles" contentEditable="true">
                  <li>Twitter</li>
                  <li>Dribbble</li>
                  <li>Codepen</li>
                </ul>
                <ul className="list-content" contentEditable="true"> 
                  <li><a href>@janderson</a></li>
                  <li><a href>janderson</a></li>
                  <li><a href>janderson</a></li>
                </ul>
              </div>
            </div>
          </section>
          <section className="experience section-padding">
            <div className="container">
              <h3 className="experience-title" contentEditable="true">Experience</h3>
              <div className="experience-wrapper" contentEditable="true">
                <div className="company-wrapper clearfix">
                  <div className="experience-title" contentEditable="true">Company name</div>
                  <div className="time" contentEditable="true">Nov 2012 - Present</div> 
                </div>
                <div className="job-wrapper clearfix" contentEditable="true">
                  <div className="experience-title" contentEditable="true"  >Front End Developer </div>
                  <div className="company-description" contentEditable="true">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce a elit facilisis, adipiscing leo in, dignissim magna.</p>  {/* JOB DESCRIPTION  */}
                  </div>
                </div>
                <div className="company-wrapper clearfix" contentEditable="true">
                  <div className="experience-title" contentEditable="true">Company name</div> 
                  <div className="time" contentEditable="true">Nov 2010 - Present</div> 
                </div>
                <div className="job-wrapper clearfix" contentEditable="true">
                  <div className="experience-title" contentEditable="true">Freelance, Web Designer / Web Developer</div>
                  <div className="company-description" contentEditable="true">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce a elit facilisis, adipiscing leo in, dignissim magna.</p>  {/* JOB DESCRIPTION  */}
                  </div>
                </div>
                <div className="company-wrapper clearfix" contentEditable="true">
                  <div className="experience-title" contentEditable="true">Company name</div>
                  <div className="time" contentEditable="true">Nov 2009 - Nov 2010</div>
                </div> 
                <div className="job-wrapper clearfix" contentEditable="true">
                  <div className="experience-title" contentEditable="true">Web Designer </div>
                  <div className="company-description" contentEditable="true">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce a elit facilisis, adipiscing leo in, dignissim magna.</p>   {/* JOB DESCRIPTION  */}
                  </div>
                </div>
              </div>
              <div className="section-wrapper clearfix" contentEditable="true">
                <h3 className="section-title" contentEditable="true">Skills</h3> 
                <ul contentEditable="true">
                  <li className="skill-percentage">HTML / HTML5</li>
                  <li className="skill-percentage">CSS / CSS3 / SASS / LESS</li>
                  <li className="skill-percentage">Javascript</li>
                  <li className="skill-percentage">Jquery</li>
                  <li className="skill-percentage">Wordpress</li>
                  <li className="skill-percentage">Photoshop</li>
                </ul>
              </div>
              <div className="section-wrapper clearfix" contentEditable="true">
                <h3 className="section-title" contentEditable="true">Hobbies</h3>
                <p contentEditable="true">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce a elit facilisis, adipiscing leo in, dignissim magna.</p>
                <p contentEditable="true">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce a elit facilisis, adipiscing leo in, dignissim magna.</p> 
              </div>
            </div>
          </section>
          <div className="clearfix" />
        </div>
        </>
      );
    }
  export default Tempfive;