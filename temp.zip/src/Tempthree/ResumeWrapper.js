import React from 'react';
import ResumeLeft from './ResumeLeft';
import html2pdf from 'html2pdf.js';
import ResumeRight from './ResumeRight';

const ResumeWrapper = () => {

    const downloadPDF = () => { 
        const element = document.querySelector('.resume_wrapper');
        const opt = {
          margin: 0.5,
          filename: 'resume.pdf',
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2 },
          jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
        };
    
        html2pdf().from(element).set(opt).save();
      };
    
  return (
    <><button onClick={downloadPDF} 
    style={{
        width: '200px',
        height: '25px',
        borderRadius: '10px',
        marginLeft: '40%',
        backgroundColor: 'red',
        color: 'white',
        marginTop: '5px'
      }}>
    Download as PDF</button>
    <div className="resume_wrapper">
      <ResumeLeft />
      <ResumeRight />
    </div>
    </>
  );

};

export default ResumeWrapper;
