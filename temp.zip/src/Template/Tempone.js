import React from 'react';
import "./tempone.css";
import html2pdf from 'html2pdf.js';
import profileImage from '../Template/profile.png';

class TempOne extends React.Component {
  state = {
    selectedImage: profileImage
  };

  handleImageChange = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = () => {
      this.setState({ selectedImage: reader.result });
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  };

  handleImageClick = () => {
    document.getElementById('imageInput').click();
  };

  downloadPDF = () => {
    const element = document.querySelector('.container');
    const opt = {
      margin: 0.5,
      filename: 'resume.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    html2pdf().from(element).set(opt).save();
  };


  render() {
    const { selectedImage } = this.state;
    return (
        <>
        <button onClick={this.downloadPDF}>Download as PDF</button>

      <div className="container" >
        <div className="header">
        <div className='img-area'>
              <img
                src={selectedImage}
                alt="Description of the image"
                onClick={this.handleImageClick}
                style={{ cursor: 'pointer' }}
              />
              <input
                type="file"
                id="imageInput"
                accept="image/*"
                onChange={this.handleImageChange}
                style={{ display: 'none' }}
              />
            </div>
          <h1 contentEditable="true">Jason Holder</h1>
          <h3 contentEditable="true">Full-Stack Web Developer</h3>
        </div>

        <div className="main">
          <div className="left">
            <h2>Personal Information</h2>
            <p contentEditable="true"><strong>Name:</strong> Jason Holder</p>
            <p contentEditable="true"><strong>Age:</strong> 30</p>
            <p contentEditable="true"><strong>Email:</strong> jholder@email.com</p>
            <p contentEditable="true"><strong>Phone:</strong> 000 000 0000</p>
            <h2>Skills</h2>
            <ul contentEditable="true">
              <li>HTML/CSS</li>
              <li>JavaScript</li>
              <li>React</li>
              <li>Node.js</li>
              <li>SQL</li>
            </ul>
            <h2>Education</h2>
            <h3 contentEditable="true">B.Sc in Computer Science</h3>
            <p contentEditable="true">University of XYZ, 2014-2018</p>
            <h3 contentEditable="true">M.Sc in Computer Science</h3>
            <p contentEditable="true">University of XYZ, 2019-2020</p>
          </div>

          <div className="right">
            <h2>Work Experience</h2>
            <h3 contentEditable="true">XYZ Company</h3>
            <p contentEditable="true"><strong>Position:</strong> Software Developer</p>
            <p contentEditable="true"><strong>Duration:</strong> 2018-2022</p>
            <ul contentEditable="true">
              <li>Developed and maintained web applications using React, Node.js, and SQL</li>
              <li>Implemented responsive design using CSS flexbox and media queries</li>
              <li>Collaborated with cross-functional teams to deliver high-quality software products</li>
            </ul>
            <h3 contentEditable="true">ABC Company</h3>
            <p contentEditable="true"><strong>Position:</strong> Web Developer</p>
            <p contentEditable="true"><strong>Duration:</strong> 2016-2018</p>
            <ul contentEditable="true">
              <li>Created and maintained websites using HTML, CSS, and JavaScript</li>
              <li>Optimized website performance and user experience using best practices</li>
              <li>Worked with clients to understand their needs and deliver custom solutions</li>
            </ul>
          </div>
        </div>
      </div>
      </>
    );
  }
}

export default TempOne;
