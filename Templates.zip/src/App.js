import React from 'react';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Tempone from "./Template/Tempone";
import Temthree from "./Tempthree/ResumeWrapper";




const App = () => {
    return (
        <BrowserRouter>
      <Routes>
       <Route path="/" element={<Tempone/>} />
        <Route path="/Tempone"  element={<Tempone/>} />
        <Route path="/ResumeWrapper " element={<Temthree />} />
      </Routes>
    </BrowserRouter>
    );
};

export default App;
