import React from 'react';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import TempOne from "./Template/Tempone";
import TempTwo from"./Temptwo/Resume";
import TepmThree from"./Tempthree/ResumeWrapper";
import TempFour from "./TemoFour/Tempfour";
import TempFive from "./Tempfive/tempfive";
import TepmSix from "./Tempsix/Tempsix";
import TempSeven from "./TempSeven/Tempseven";

const App = () => {
    return (
        <BrowserRouter>
      <Routes>
        <Route path="/" element={<TempSeven/>} />
        <Route path="/Tempone"  element={<TempOne/>} />
        <Route path="/Resume"  element={<TempTwo/>} />
        <Route path="/ResumeWrapper"  element={<TepmThree/>} />
        <Route path="/Tempfour"  element={<TempFour/>} />
        <Route path="/Tempfive"  element={<TempFive/>} />
        <Route path="/Tempsix"  element={<TepmSix/>} />
        <Route path="/Tempseven"  element={<TempSeven/>} />
      </Routes>
    </BrowserRouter>
    );
};

export default App;
